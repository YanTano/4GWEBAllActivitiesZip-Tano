<!DOCTYPE html>
  <html lang="en"> 
    <head>
      <!-- meta tag -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      
      <title> VIVAMUS </title>

      <!-- css link -->
      <link rel="stylesheet" type="text/css" href="assets/css/css.css">

      <!-- php arrays -->
      <?php 
        $toplabel = array("Bibendum", "Sollicitudin", "Metus","Egestas");
        $inputlabel = array("First name*","Last name*","Email Address*","Mobile Number*");
      ?>
    </head>

        <body>

          <header>
          <!-- vivamus logo -->
            <div id="logo">
              <a href="#"><img src="assets/images/VIVA_LOGO.png" alt="logo"></a>
            </div>
            
          <!-- Navigation Menu -->
              <nav id="top-nav"> 
                <span class="with-bar"><a href="#" ><?php print $toplabel[0];?></a></span>
                <span class="with-bar"><a href="#" ><?php print $toplabel[1];?></a></span>
                <span class="with-bar"><a href="#" ><?php print $toplabel[2];?></a></span>
                <span><a href="#" ><?php print $toplabel[3];?></a></span> 
              </nav>
          <!-- Search Box -->
                <div id="search-box">
                   <input type="text">
                    <button type="submit" id="search-icon"><img src="assets/images/MAGNIFYING.png" alt="magnifying"></button>
                </div>
          </header>
