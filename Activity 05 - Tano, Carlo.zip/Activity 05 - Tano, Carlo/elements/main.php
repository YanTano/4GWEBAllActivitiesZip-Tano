
          <!-- Main Form-->
          <main id="mainForm">
          <!-- Title Bar --> 
            <div class="titleBar">
              <h1 class="title">In euismod sapien eu maximus tempus</h1> 
              <h2 class="title-description">Vestibulum bibendum posuere dui, in pharetra est hendreit ac.<br>Integer posuere metus lacus</h2> 
              <h1 class="title">Vivamus interdum nunc ac sem fringilla </h1>
              <h2 class="title-description">duis risus urna, mattis eget justo non, gravida ultrices diam</h2>
              <h1 class="title">In euismod sapien eu maximus tempus.</h1>
              <h2 class="title-description">Vestibulum bibendum posuere dui, in pharetra est hendrerit ac.<br> Integer posuere metus lacus</h2>
            </div>
          <!-- Progress Bar 123 -->
              <div id="progressBar"></div>
                <div id="steps-container">
                <div id="step2"><span class="step"> 2 </span></div>
                 <span id="step1"> 1 </span>
                 <span id="step3" class="step"> 3 </span>
              </div>
              
          <!-- Form --> 
                <form id="regForm" action="assets/php/connect.php" method="POST">

          <!-- Form First Page (One Tab on Each Step of the Form)-->
                  <div class="tab">
                    <div class="panel1">
                      <div class="panelHeading">
                        <h3 class="panelTitle">About you</h3>
                      </div>
                        <div class="panel-forms1">
                        <div class="first-name">
                            <label for="fname"><?php echo $inputlabel[0]?></label><br>
                            <input type="text" id="fname" name="firstName" required>
                            <div id="fname-error" class="error"></div>
                          </div>
                          <div class="last-name">
                            <label for="lname"><?php echo $inputlabel[1]?></label><br>
                            <input type="text" id="lname"  name="lastName" required>
                            <div id="lname-error" class="error"></div>
                          </div><br>
                            <label for="email"><?php echo $inputlabel[2]?></label><br>
                            <input type="email" id="email"  name="email" required><br>
                            <div id="email-error" class="error"></div>

                            <label for="phone"><?php echo $inputlabel[3]?></label><br>
                            <input type="tel" id="phone" name="number" required>
                            <div id="number-error" class="error"></div>
                          </div>
                    </div>
                  </div>

          <!-- Form Second Page (One Tab on Each Step of the Form)--> 
                    <div class="tab"> 
                      <div class="panel2">
                        <div class="panelHeading">
                          <h4 class="panelTitle">Your donation</h4>
                        </div>
                          <div class="panel-forms2">

          <!-- Step 2 Paypal & Credit Card Button --> 
                            <div id="payment">
                              <span id="paypal-btn">Paypal</span>
                                <span id="credit-btn">Credit Card</span>
                              </div>
          <!-- Step 2 Paypal Form --> 
                              <div id="paypal-form">
                                <h5><br>Vivamus Service Advisory</h5>
                                <p id="advisory">March 25, 2022<br><br>
                                  Paypal service in the Vivamus Website is<br> temporarily unavailable. Rest assured that<br> we're working hard to restore this service as<br> soon as possible.<br><br>Thank you.
                                </p>
                              </div>
          <!-- Step 2 Credit Card Form --> 
                              <div id="credit-form">
                                <label class="donationLabel" for="donation">Donation Amount*</label><br>
                                <input type="number" id="donation" name="donated" required>
                                <div id="donation-error" class="error"></div><br>

                                <label class="donationLabel" for="cardHolder">Card Holder Name*</label><br>
                                <input type="text" id="cardHolder" name="cardHolder" required>
                                <div id="holder-error" class="error"></div><br>

                                <label class="donationLabel" for="cardNum">Credit Card No.*</label><br>
                                <input type="number" id="cardNum" name="cardNumber" required>
                                <div id="card-error" class="error"></div><br>

                                <label class="donationLabel" for="code">Card Security Code*</label><br>
                                <input type="password" id="code" name="code" required>
                                <div id="code-error" class="error"></div><br>

                                <label class="donationLabel" for="exDate">Expiry Date*</label><br>
                                <input type="text" id="exDate" name="date" placeholder="MM / YY" required>
                                <div id="date-error" class="error"></div><br>
                                
          <!-- Step 2 Visa & Mastercard Logo --> 
                                <div id="visa-logo"><img src="assets/images/Visa_Logo.png" alt="visa"></div>                     
                                <div id="mastercard-logo"><img src="assets/images/Mastercard_Logo.png" alt="mastercard"></div>
                              </div>
                          </div>
                      </div>
                    </div>

          <!-- Form Third Page (One Tab on Each Step of the Form)-->                
                      <div class="tab">
                        <div class="panel3">
                          <div class="panelHeading">
                            <h6 class="panelTitle">Comment Field</h6>
                          </div>
          <!-- Step3 Message Textfield -->              
                          <label class="message-label" for="message">Your Message</label><br>
                          <textarea id="message" name="message" required></textarea><br>
          <!-- Step3 Checkbox Anonymous--> 
                          <input type="checkbox" id="anonymous" name="hidden" value="yes">
                          <label class="anonymous-label" for="anonymous">Keep me anonymous</label><br>
                        </div>
                      </div>
          <!-- Buttons Next, Back & Submit--> 
                      <div >
                        <div >
                          <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
                          <button type="button" id="nextBtn" onclick="nextPrev(1)">Next</button>
                        </div>
                      </div>

                </form>
          </main>