
          <!-- Footer -->
          <footer id="footer">

          <!-- Footer Circles -->
            <div id="circle-row">
                <span><button class="circle"></button></span>
                <span><button class="circle"></button></span>
                <span><button class="circle"></button></span>
                <span><button class="circle"></button></span>
                <span><button class="circle"></button></span>
            </div>
          <!-- Footer Navigation Bar -->
            <div id="foot-nav">
                <span><a href="#">Pellentesque</a></span>
                <span><a href="#">Et interdum</a></span>
                <span><a href="#">Neque</a></span>
                <span><a href="#">Integer</a></span>
                <span><a href="#">Ullamcorper</a></span>
                <span><a href="#">Sagitis</a></span>
            </div>
          <!-- Footer Copyright -->
              <p>Copyright Ⓒ 2015 Proin eget ipsum libero<br>All Rights Reserved.</p>
          
          </footer>

          <!-- Javascript Link -->
             <script src="assets/js/myscript.js"></script>
        
      </body>
</html>

