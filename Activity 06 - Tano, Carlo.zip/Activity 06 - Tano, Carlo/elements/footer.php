
          <footer>
            <p id="footer-content">&copy; 2022 Carlo Tano.</p>
            <a href="https://www.facebook.com/carlo.tano.9" id="fb-logo" ><img src="assets/images/fblogo.png" alt="Facebook Logo" ></a>
          </footer>
    </body>
</html>