<!DOCTYPE html>
  <html lang="en"> 
    <head>
      <!-- meta tag -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      
      <title> VIVAMUS </title>

      <!-- css link -->
      <link rel="stylesheet" type="text/css" href="assets/css/css.css">
    </head>

        <body>

          <header>
          <!-- vivamus logo -->
            <div id="logo">
              <a href="#"><img src="assets/images/VIVA_LOGO.png" alt="logo"></a>
            </div>
            
          <!-- Navigation Menu -->
              <nav id="top-nav"> 
                <span class="with-bar"><a href="#" >Bibendum</a></span>
                <span class="with-bar"><a href="#" >Sollicitudin</a></span>
                <span class="with-bar"><a href="#" >Metus</a></span>
                <span><a href="#" >Egestas</a></span> 
              </nav>
          <!-- Search Box -->
                <div id="search-box">
                   <input type="text">
                    <button type="submit" id="search-icon"><img src="assets/images/MAGNIFYING.png" alt="magnifying"></button>
                </div>
          </header>