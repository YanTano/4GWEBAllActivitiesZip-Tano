<!DOCTYPE html>
<html lang="en">
  <head>
    <title>TANO BIOGRAPHY</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="assets/css/biographyStyle.css">
    <?php
      function genInfo(){
        $generalInfo = array("Name:", "Age:", "Country:");
        $genlength = count($generalInfo);
          for($x = 0; $x < $genlength; $x++) {
            echo $generalInfo[$x];
            echo str_repeat('&nbsp;', 11);
          }
      }
      function inInfo(){
        $inputInfo = array("Carlo Tano", "25", "Philippines");
        $inputlength = count($inputInfo);
          for($x = 0; $x < $inputlength; $x++) {
            echo $inputInfo[$x];
            echo str_repeat('&nbsp;', 8);
          }
      }
    ?>
  </head>

    <body style="background-image: url(assets/images/backgroundcover.jpg)">
      <header>
        <svg id="profile-svg" viewbox="0 0 700 200">
          <polyline id="profile-background" points="65,170 145,170 145,50 135,40 135,10 125,0 70,0 10,0 0,10 0,160 10,170 70,170" ></polyline>
            <image href="assets/images/myPic.png" id="myPhoto" height="168px" width="108px"></image>
        </svg>
          
        <svg id="info-svg" viewbox="0 0 700 200">
          <polyline id="info-background" points="145,85 250,85 260,95 490,95 500,105 500,135 500,150 490,160 200,160 190,170 145,170 "></polyline>
            
            <text id="generalInfo" >
              <?php echo(genInfo()); ?>
            </text>
              
              <text id="inputInfo">
                <?php echo(inInfo()); ?>
              </text>
        </svg>

        <div class="air">
          <img src="assets/images/myAirplane.png" alt="Boing 737">
        </div>
      </header>
      
        <main id="biography-content">
          <h1>BIOGRAPHY</h1>
      
            <p id="main-content">I'm Carlo Tano I am a second year student at the Center for Industrial Technology and Enterprise pursuing a Diploma in Computer Engineering. My long-term aim is to earn a Bachelor's Degree in Computer Engineering as well as a Commercial Pilot License. Most relevant I've been working on is Vivamus a fundraising web page & applying in free flight trainings. At CITE we have also worked on projects involving the development of various e-commerce websites. I had experienced in developing projects using various programming languages such as Java, C++, etc. as well as with a number of programming tools such as MYSQ, C# and also with HTML/CSS. I believe in saying "As much as the world fails you, never regret having a good heart". My tale follows: This is my Third life chance. I'm looking forward to spend it something significant. At my young age I got hospitalized for abrasion in head & dengue fever. The third was this past 4 years I was diagnosed in kidney disease, gal stone and pulmonary and gastrointestinal tuberculosis. I saw no reason to give up God save me that day even my bills. My father and mother always working to the bones for me. So I swore to myself I'd sharpen up fast and become a man capable of helping them. I spend my free time praying and spending time with my family. I am now seeking for new challenges after this semester, and hopes to work as a web developer.
            </p> 
        </main>
          
          <footer>
            <p id="footer-content">&copy; 2022 Carlo Tano.</p>
            <a href="https://www.facebook.com/carlo.tano.9" id="fb-logo" ><img src="assets/images/fblogo.png" alt="Facebook Logo" ></a>
          </footer>
    </body>
</html>