<?php
	include("elements/header.php");
	include("elements/main.php");
	include("elements/footer.php");
?>