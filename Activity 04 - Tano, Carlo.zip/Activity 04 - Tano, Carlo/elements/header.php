<!DOCTYPE html>
<html lang="en">
  <head>
    <title>TANO BIOGRAPHY</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="assets/css/biographyStyle.css">
    <?php
      function genInfo(){
        $generalInfo = array("Name:", "Age:", "Country:");
        $genlength = count($generalInfo);
          for($x = 0; $x < $genlength; $x++) {
            echo $generalInfo[$x];
            echo str_repeat('&nbsp;', 11);
          }
      }
      function inInfo(){
        $inputInfo = array("Carlo Tano", "25", "Philippines");
        $inputlength = count($inputInfo);
          for($x = 0; $x < $inputlength; $x++) {
            echo $inputInfo[$x];
            echo str_repeat('&nbsp;', 8);
          }
      }
    ?>
  </head>

    <body style="background-image: url(assets/images/backgroundcover.jpg)">
      <header>
        <svg id="profile-svg" viewbox="0 0 700 200">
          <polyline id="profile-background" points="65,170 145,170 145,50 135,40 135,10 125,0 70,0 10,0 0,10 0,160 10,170 70,170" ></polyline>
            <image href="assets/images/myPic.jpg" id="myPhoto" height="168px" width="108px"></image>
        </svg>
          
        <svg id="info-svg" viewbox="0 0 700 200">
          <polyline id="info-background" points="145,85 250,85 260,95 490,95 500,105 500,135 500,150 490,160 200,160 190,170 145,170 "></polyline>
            
            <text id="generalInfo" >
              <?php echo(genInfo()); ?>
            </text>
              
              <text id="inputInfo">
                <?php echo(inInfo()); ?>
              </text>
        </svg>

        <div class="air">
          <img src="assets/images/myAirplane.png" alt="Boing 737">
        </div>
      </header>