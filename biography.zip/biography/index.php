<?php
	$mysqli = new mysqli("localhost","root","","biography");
		if ($mysqli -> connect_errno) {
  			echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  			exit();
		}
/*
		$sql = "INSERT INTO biography (name, age, country)
		VALUES ('Carlo Tano', '25', 'Philippines')";

		if ($mysqli->query($sql) === TRUE) {
  			echo "New record created successfully";
		} else {
  			echo "Error: " . $sql . "<br>" . $mysqli->error;
		}
*/
     
include("elements/header.php");
include("elements/main.php");
include("elements/footer.php");

?>