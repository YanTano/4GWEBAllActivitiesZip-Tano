<?php
	$mysqli = new mysqli("localhost","root","","biography");
		if ($mysqli -> connect_errno) {
  			echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
  			exit();
		}
/*
		$sql = "INSERT INTO info (Name, Age, Country)
		VALUES ('Carlo', '25', 'Philippines')";

		if ($mysqli->query($sql) === TRUE) {
  			echo "New record created successfully";
		} else {
  			echo "Error: " . $sql . "<br>" . $conn->error;
		}
*/
     
include("elements/header.php");
include("elements/main.php");
include("elements/footer.php");

?>